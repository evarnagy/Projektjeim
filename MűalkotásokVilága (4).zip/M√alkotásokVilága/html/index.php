<?php
$search_result = "";
$found = false;

if ($_SERVER["REQUEST_METHOD"] == "GET" && !empty($_GET["search_term"])) {
    $search_term = htmlspecialchars($_GET["search_term"]);
    $data = file_get_contents("../html/index.php");

    if (stripos($data, $search_term) !== false) {
        $found = true;
        $search_result = "A keresett kifejezés megtalálható: " . htmlspecialchars($search_term);
    } else {
        $search_result = "A keresett kifejezés nem található.";
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Műalkotások Világa</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
<header>
<h1>Műalkotások Világa</h1>
  <nav>
    <ul>
      <li><a href="index.php">Főoldal</a></li>
      <li><a href="info.php">Információ</a></li>
      <li><a href="kosar.php">Kosár</a></li>
      <li><a href="profil.php">Profil</a></li>
        <li><a href="velemeny.php">Velemeny</a></li>
      <li><a href="bejelentkezes.php">Bejelentkezés</a></li>
      <li><a href="regisztracio.php">Regisztráció</a></li>
        <li><a href="kijelentkezes.php">Kijelentkezés</a></li>
        <form action="index.php" method="get">
            <label>
                <input type="text" name="search_term" class="kereso-doboz" placeholder="Keresés...">
            </label>
            <button type="submit" class="kereso-gomb">🔍</button>
        </form>


    </ul>
  </nav>

</header>
<main id="page">
    <div>
        <?php if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["search_term"])): ?>
            <p><?php echo $search_result; ?></p>
        <?php endif; ?>
    </div>
  <section>
    <h1>Ha szereted a művészetet, és arra vágysz, hogy otthonodat vagy irodádat egyedi és lenyűgöző festményekkel díszítsd, akkor jó helyen jársz!
    </h1>
    <h1>Webáruházunkban széles választékban kínálunk festményeket, amelyek segítségével egy csodálatos művészeti világba merülhets
    </h1>
  </section>

  <section>


    <div class="gallery">

      <div class="canvas">

        <a href="kosar.php">
        <img src="../htmlkepek/csillagos-ej-van-gogh.jpg" alt="Csillagos éj">

        <div class="cim">Vincent van Gogh: Csillagos éj</div>
        <div class="ar">139 900 Ft
          <span class="eredetiar">254 360 Ft</span>
          <span class="arazas">-45%</span>
        </div>
        </a>
      </div>

      <div class="canvas">
        <a href="kosar.php">
        <img src="../htmlkepek/f9a7a187-484e-4821-b84a-79c836109029.jpg" alt="Festett valami">

        <div class="cim">Vincent van Gogh: Önarckép</div>
        <div class="ar">294 322 Ft
          <span class="eredetiar">654 050 Ft</span>
          <span class="arazas">-45%</span>
        </div>
        </a>
      </div>

      <div class="canvas">
        <a href="kosar.php">
        <img src="../htmlkepek/sikoly.jpg" alt="Várost nézve részegen">

        <div class="cim">Edvard Munch: A sikoly</div>
        <div class="ar">87 500 Ft
          <span class="eredetiar">250 000 Ft</span>
          <span class="arazas">-35%</span>
        </div>
        </a>
      </div>
    </div>
    <div class="gallery">
      <div class="canvas">
        <a href="kosar.php">
        <img src="../htmlkepek/sandro-boticelli-venusz-szuletese-01.jpg" alt="Csillagos éj">

        <div class="cim">Sandro Botticelli: Vénusz születése.</div>
        <div class="ar">13 990 Ft
          <span class="eredetiar">15 000 Ft</span>
          <span class="arazas">-10%</span>
        </div>
        </a>
      </div>

      <div class="canvas">
        <a href="kosar.php">
        <img src="../htmlkepek/146.jpg" alt="Festett valami">
        <a href="kosar.php"></a>
        <div class="cim">Leonardo da Vinci: Az utolsó vacsora.</div>
        <div class="ar">13 990 Ft
          <span class="eredetiar">27 980 Ft</span>
          <span class="arazas">-50%</span>
        </div>
        </a>
      </div>

      <div class="canvas">
        <a href="kosar.php">
        <img src="../htmlkepek/hires-festmenyek-karikaturai-003-676x1024.jpg" alt="Várost nézve részegen">

        <div class="cim">MonaBean</div>
        <div class="ar">13 990 Ft
          <span class="eredetiar">139 900 Ft</span>
          <span class="arazas">-90%</span>
        </div>
        </a>

      </div>
    </div>

  </section>


</main>

</body>
</html>