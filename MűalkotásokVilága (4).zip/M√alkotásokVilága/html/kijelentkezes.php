<?php
session_start();

if (!isset($_SESSION['username'])) {

    header("Location: bejelentkezes.php");
    exit();
}
session_start();
session_unset();
session_destroy();

header("Location: bejelentkezes.php");


