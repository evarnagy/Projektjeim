<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["email"]) && isset($_POST["password"])) {

        $email = $_POST["email"];
        $password = $_POST["password"];


        $users_json = file_get_contents("../json/users.json");
        $users = json_decode($users_json, true);

        $authenticated_user = null;
        foreach ($users as $user) {
            if ($user["email"] === $email && password_verify($password, $user["password"])) {
                $authenticated_user = $user;
                break;
            }
        }


        if ($authenticated_user !== null) {
            session_start();
            $_SESSION["username"] = $authenticated_user["username"];
            header("Location: profil.php");
            exit();
        } else {
            echo "<div style='text-align: center;'>";
            echo "<p style='color: red; font-weight: bold;'>Hibás email cím vagy jelszó!</p>";
            echo "</div>";
        }
    } else {
        echo "<div style='text-align: center;'>";
        echo "<p style='color: red; font-weight: bold;'>Hiányzó adatok!</p>";
        echo "</div>";
    }
}

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Saját oldal</title>
    <link rel="stylesheet" href="../css/Cssbejelent.css">
</head>

<body>
<header>
    <h1>Műalkotások Világa</h1>
    <nav>
        <ul>
            <li><a href="index.php">Főoldal</a></li>
            <li><a href="info.php">Információ</a></li>
            <li><a href="kosar.php">Kosár</a></li>
            <li><a href="profil.php">Profil</a></li>
            <li><a href="bejelentkezes.php">Bejelentkezés</a></li>
            <li><a href="regisztracio.php">Regisztráció</a></li>
            <li><a href="kijelentkezes.php">Kijelentkezés</a></li>


        </ul>
    </nav>
</header>
<main id="page" >
    <div class="login-box">
        <div class="login-header">
            <header>Bejelentkezés</header>
        </div>
        <form action="bejelentkezes.php" method="post">
            <div class="input-box">
                <label>
                    <input type="text" name="email" class="input-field" placeholder="Email" autocomplete="off" required>
                </label>
            </div>
            <div class="input-box">
                <label>
                    <input type="password" name="password" class="input-field" placeholder="Jelszó" autocomplete="off" required>
                </label>
            </div>
            <div class="forgot">
                <section>
                    <input type="checkbox" id="check">
                    <label for="check">Emlékezzen rám</label>
                </section>
                <section>
                    <a href="regisztracio.php">Elfelejtetted a jelszót?</a>
                </section>
            </div>
            <div class="input-submit">
                <button type="submit" class="submit-btn" id="submit">Bejelentkezés</button>
            </div>
        </form>
        <div class="sign-up-link">
            <p>Nincs még fiókod ? <a href="regisztracio.php">Regisztráció</a></p>
        </div>
    </div>
</main>
</body>
</html>

