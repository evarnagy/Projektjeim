<?php
$search_result = "";
$found = false;

if ($_SERVER["REQUEST_METHOD"] == "GET" && !empty($_GET["search_term"])) {
    $search_term = htmlspecialchars($_GET["search_term"]);
    $data = file_get_contents("../html/velemeny.php");

    if (stripos($data, $search_term) !== false) {
        $found = true;
        $search_result = "A keresett kifejezés megtalálható: " . htmlspecialchars($search_term);
    } else {
        $search_result = "A keresett kifejezés nem található.";
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Műalkotások Világa</title>
    <link rel="stylesheet" href="../css/Cssbejelent.css">
</head>

<body>
<header>
    <h1>Műalkotások Világa</h1>
    <nav>
        <ul>
            <li><a href="index.php">Főoldal</a></li>
            <li><a href="info.php">Információ</a></li>
            <li><a href="kosar.php">Kosár</a></li>
            <li><a href="profil.php">Profil</a></li>
            <li><a href="velemeny.php">Vélemény</a></li>
            <li><a href="bejelentkezes.php">Bejelentkezés</a></li>
            <li><a href="regisztracio.php">Regisztráció</a></li>
            <li><a href="kijelentkezes.php">Kijelentkezés</a></li>
            <form action="velemeny.php" method="get">
                <label>
                    <input type="text" name="search_term" class="kereso-doboz" placeholder="Keresés...">
                </label>
                <button type="submit" class="kereso-gomb">🔍</button>
            </form>
            <div>
                <?php if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["search_term"])): ?>
                    <p><?php echo $search_result; ?></p>
                <?php endif; ?>
            </div>
        </ul>
    </nav>
</header>
<main id="page">
    <div class="login-box">
        <div class="login-header">
            <header>Vélemény beküldése</header>
        </div>
        <form action="opinionsaver.php" method="post">
            <div class="input-box">
                <label>
                    <input type="text" name="name" class="input-field" placeholder="Név" autocomplete="off" required>
                </label>
            </div>
            <div class="input-box">
                <label>
                    <input type="text" name="keptema" class="input-field" placeholder="Melyik képről írsz ?" autocomplete="off" required>
                </label>
            </div>
            <div class="input-box">
                <label>
                    <textarea name="velemeny" class="input-field" placeholder="Írja meg véleményét" autocomplete="off" required style="height: 100px;"></textarea>
                </label>
            </div>
            <div class="input-box">
                <label>
                    <input type="text" name="kedvenckep" class="input-field" placeholder="Önnek melyik kép tetszett meg a legjobban?" autocomplete="off" required>
                </label>
            </div>
            <div class="input-submit">
                <button type="submit" class="submit-btn">Beküld</button>
            </div>
        </form>
    </div>
</main>


</body>
</html>
