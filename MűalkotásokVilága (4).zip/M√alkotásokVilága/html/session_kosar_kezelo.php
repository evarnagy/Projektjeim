<?php
session_start();

if (!isset($_SESSION['kosar'])) {
    $_SESSION['kosar'] = array();
}
function addToCart($item, $quantity = 1) {
    if (isset($_SESSION['kosar'][$item])) {
        $_SESSION['kosar'][$item] += $quantity;
    } else {
        $_SESSION['kosar'][$item] = $quantity;
    }
}


