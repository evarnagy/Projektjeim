<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = strip_tags($_POST['name']);
    $picture_subject = strip_tags($_POST['keptema']);
    $opinion = strip_tags($_POST['velemeny']);
    $favorite_picture = strip_tags($_POST['kedvenckep']);

    $data = "Név: " . $name . "\nKépről: " . $picture_subject . "\nVélemény: " . $opinion . "\nLegjobban tetszett kép: " . $favorite_picture . "\n---\n";

    $filePath = "../velemenyek/opinions.txt";
    file_put_contents($filePath, $data, FILE_APPEND);
    header('Location: index.php');
    exit();
}



