<?php
include 'session_kosar_kezelo.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'add' && !empty($_POST['item_id'])) {
        addToCart($_POST['item_id']);
        header("Location: kosar.php");
        exit;
    }
}


