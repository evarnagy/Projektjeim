<?php
$search_result = "";
$found = false;

if ($_SERVER["REQUEST_METHOD"] == "GET" && !empty($_GET["search_term"])) {
    $search_term = htmlspecialchars($_GET["search_term"]);
    $data = file_get_contents("../html/kosar.php");

    if (stripos($data, $search_term) !== false) {
        $found = true;
        $search_result = "A keresett kifejezés megtalálható: " . htmlspecialchars($search_term);
    } else {
        $search_result = "A keresett kifejezés nem található.";
    }
}
include 'session_kosar_kezelo.php';

echo '<h1>Kosár tartalma</h1>';
if (!empty($_SESSION['kosar'])) {
    foreach ($_SESSION['kosar'] as $item => $quantity) {
        echo "<p>$item - Darabszám: $quantity</p>";
    }
} else {
    echo "<p>A kosár üres</p>";
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Műalkotások Világa</title>
  <link rel="stylesheet" href="../css/style.css">
</head>

<body>
<header>
  <h1>Műalkotások Világa</h1>
  <nav>
    <ul>
      <li><a href="index.php">Főoldal</a></li>
      <li><a href="info.php">Információ</a></li>
      <li><a href="kosar.php">Kosár</a></li>
      <li><a href="profil.php">Profil</a></li>
        <li><a href="velemeny.php">Velemeny</a></li>
      <li><a href="bejelentkezes.php">Bejelentkezés</a></li>
      <li><a href="regisztracio.php">Regisztráció</a></li>
        <li><a href="kijelentkezes.php">Kijelentkezés</a></li>
        <form action="kosar.php" method="get">
            <label>
                <input type="text" name="search_term" class="kereso-doboz" placeholder="Keresés...">
            </label>
            <button type="submit" class="kereso-gomb">🔍</button>
        </form>
    </ul>
  </nav>
</header>
<main id="page">
<section>
  <div class="canvas">
      <div>
          <?php if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["search_term"])): ?>
              <p><?php echo $search_result; ?></p>
          <?php endif; ?>
      </div>
    <a href="kosar.php">
        <img src="../htmlkepek/hires-festmenyek-karikaturai-003-676x1024.jpg" alt="MonaBeen">
        <div class="cim">MonaBean</div>
        <div class="ar">13 990 Ft
            <span class="eredetiar">139 900 Ft</span>
            <span class="arazas">-90%</span>
        </div>
    </a>
      <a href="../htmlkepek/hires-festmenyek-karikaturai-003-676x1024.jpg" download="MonaBean.jpg" class="download-button">Kép letöltése</a>
  </div>
    <form action="kosar_kezelo.php" method="post">
        <input type="hidden" name="item_id" value="MonaBean">
        <input type="hidden" name="action" value="add">
        <button type="submit" class="kosarba-gomb">Kosárba</button>
    </form>
</section>
</main>
</body>
</html>