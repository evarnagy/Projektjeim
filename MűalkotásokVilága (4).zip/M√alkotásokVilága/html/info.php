<?php
$search_result = "";
$found = false;

if ($_SERVER["REQUEST_METHOD"] == "GET" && !empty($_GET["search_term"])) {
    $search_term = htmlspecialchars($_GET["search_term"]);
    $data = file_get_contents("../html/info.php");

    if (stripos($data, $search_term) !== false) {
        $found = true;
        $search_result = "A keresett kifejezés megtalálható: " . htmlspecialchars($search_term);
    } else {
        $search_result = "A keresett kifejezés nem található.";
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Műalkotások Világa</title>
    <link rel="stylesheet" href="../css/info.css">
</head>

<body>
<header>
    <h1>Műalkotások Világa</h1>
    <nav>
        <ul>
            <li><a href="index.php">Főoldal</a></li>
            <li><a href="info.php">Információ</a></li>
            <li><a href="kosar.php">Kosár</a></li>
            <li><a href="profil.php">Profil</a></li>
            <li><a href="velemeny.php">Velemeny</a></li>
            <li><a href="bejelentkezes.php">Bejelentkezés</a></li>
            <li><a href="regisztracio.php">Regisztráció</a></li>
            <li><a href="kijelentkezes.php">Kijelentkezés</a></li>
            <form action="info.php" method="get">
                <label>
                    <input type="text" name="search_term" class="kereso-doboz" placeholder="Keresés...">
                </label>
                <button type="submit" class="kereso-gomb">🔍</button>
            </form>
        </ul>
    </nav>
</header>
<main>

    <div id="search-results">
        <?php if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["search_term"])): ?>
            <p><?php echo $search_result; ?></p>
        <?php endif; ?>
    </div>

    <table>

        <tr>
            <th>Név</th>
            <th>Kor</th>
            <th>Foglalkozás</th>
            <th>Lakóhely</th>
            <th>Telefonszám</th>
            <th>Email cím</th>
        </tr>
        <tr>
            <td>Mikus Márk Barnabás</td>
            <td>22</td>
            <td>Egyetemi halgató</td>
            <td>Esztergom</td>
            <td>+36 20 5653302</td>
            <td>mikusmark2002@gmail.com</td>
        </tr>
        <tr>
            <td>Erik Vármegyei</td>
            <td>22</td>
            <td>Egyetemi halgató</td>
            <td>Szeged</td>
            <td>+36 70 6440027</td>
            <td>varnagyerik9@gmail.com</td>
        </tr>
    </table>
</main>
</body>
</html>
