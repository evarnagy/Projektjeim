<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["username"]) && isset($_POST["password"]) && isset($_POST["confirm_password"]) && isset($_POST["email"])) {

        $username = $_POST["username"];
        $password = $_POST["password"];
        $confirm_password = $_POST["confirm_password"];
        $email = $_POST["email"];

        if ($password === $confirm_password) {
            $users_json = file_get_contents("../json/users.json");
            $users = json_decode($users_json, true);

            $existing_user = false;
            foreach ($users as $user) {
                if ($user["username"] === $username || $user["email"] === $email) {
                    $existing_user = true;
                    break;
                }
            }

            if (!$existing_user) {
                $new_user = array(
                    "username" => $username,
                    "password" => password_hash($password, PASSWORD_DEFAULT), // Jelszó biztonságosan tárolása
                    "email" => $email
                );
                $users[] = $new_user;

                file_put_contents("../json/users.json", json_encode($users));

                header("Location: bejelentkezes.php");
                exit();
            } else {
                echo "<div style='text-align: center;'>";
                echo "<p style='color: red; font-weight: bold;'>A felhasználónév avagy az email cím már foglalt!</p>";
                echo "</div>";
            }
        } else {
            echo "<div style='text-align: center;'>";
            echo "<p style='color: red; font-weight: bold;'>A jelszavak nem egyeznek!</p>";
            echo "</div>";
        }
    } else {
        echo "<div style='text-align: center;'>";
        echo "<p style='color: red; font-weight: bold;'>Hiányzó adatok!</p>";
        echo "</div>";
    }
}

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Saját oldal</title>
    <link rel="stylesheet" href="../css/Cssbejelent.css">
</head>

<body>
<header>
    <h1>Műalkotások Világa</h1>
    <nav>
        <ul>
            <li><a href="index.php">Főoldal</a></li>
            <li><a href="info.php">Információ</a></li>
            <li><a href="kosar.php">Kosár</a></li>
            <li><a href="profil.php">Profil</a></li>
            <li><a href="bejelentkezes.php">Bejelentkezés</a></li>
            <li><a href="regisztracio.php">Regisztráció</a></li>
            <li><a href="kijelentkezes.php">Kijelentkezés</a></li>

        </ul>
    </nav>
</header>
<main id="page" >
    <div class="login-box">
        <div class="login-header">
            <header>Regisztráció</header>
        </div>
        <form action="regisztracio.php" method="post">
            <div class="input-box">
                <label>
                    <input type="text" name="username" class="input-field" placeholder="Felhasználó név" autocomplete="off" required>
                </label>
            </div>
            <div class="input-box">
                <label>
                    <input type="password" name="password" class="input-field" placeholder="Jelszó" autocomplete="off" required>
                </label>
            </div>
            <div class="input-box">
                <label>
                    <input type="password" name="confirm_password" class="input-field" placeholder="Jelszó újra" autocomplete="off" required>
                </label>
            </div>
            <div class="input-box">
                <label>
                    <input type="text" name="email" class="input-field" placeholder="Email-cím" autocomplete="off" required>
                </label>
            </div>
            <div class="forgot">
                <section>
                    <input type="checkbox" id="check">
                    <label for="check">Emlékezzen rám</label>
                </section>

            </div>
            <div class="input-submit">
                <button type="submit" class="submit-btn" id="submit">Regisztráció</button>
            </div>
        </form>
    </div>
</main>
</body>
</html>



