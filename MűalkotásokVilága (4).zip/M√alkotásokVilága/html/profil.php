
<?php
session_start();


if (!isset($_SESSION['username'])) {
    header("Location: bejelentkezes.php");
    exit();
}
if (isset($_FILES["profile-pic"])) {
    $engedelyezett_kiterjesztesek = ["jpg", "jpeg", "png"];

    $kiterjesztes = strtolower(pathinfo($_FILES["profile-pic"]["name"], PATHINFO_EXTENSION));

    if (in_array($kiterjesztes, $engedelyezett_kiterjesztesek)) {

        if ($_FILES["profile-pic"]["error"] === 0) {

            if ($_FILES["profile-pic"]["size"] <= 31457280) {
                $cel = "../htmlkepek/" . $_FILES["profile-pic"]["name"];
                if (file_exists($cel)) {
                    echo "<strong>Figyelem:</strong> A régebbi fájl felülírásra kerül! <br/>";
                }

                if (move_uploaded_file($_FILES["profile-pic"]["tmp_name"], $cel)) {
                    echo "Sikeres fájlfeltöltés! <br/>";
                } else {
                    echo "<strong>Hiba:</strong> A fájl átmozgatása nem sikerült! <br/>";
                }
            } else {
                echo "<strong>Hiba:</strong> A fájl mérete túl nagy! <br/>";
            }
        } else {
            echo "<strong>Hiba:</strong> A fájlfeltöltés nem sikerült! <br/>";
        }
    } else {
        echo "<strong>Hiba:</strong> A fájl kiterjesztése nem megfelelő! <br/>";
    }
}


$users_json = file_get_contents("../json/users.json");
$users = json_decode($users_json, true);


$current_user_index = null;
foreach ($users as $index => $user) {
    if ($user["username"] === $_SESSION['username']) {
        $current_user_index = $index;
        break;
    }
}


if ($current_user_index === null) {

    header("Location: bejelentkezes.php");
    exit();
}


if (isset($_POST['delete_profile'])) {
    array_splice($users, $current_user_index, 1);
    file_put_contents("../json/users.json", json_encode($users));
    session_destroy();
    header("Location: regisztracio.php");

    exit();
}

$search_result = "";
$found = false;

if ($_SERVER["REQUEST_METHOD"] == "GET" && !empty($_GET["search_term"])) {
    $search_term = htmlspecialchars($_GET["search_term"]);
    $data = file_get_contents("../html/profil.php");

    if (stripos($data, $search_term) !== false) {
        $found = true;
        $search_result = "A keresett kifejezés megtalálható: " . htmlspecialchars($search_term);
    } else {
        $search_result = "A keresett kifejezés nem található.";
    }
}

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Saját oldal</title>
    <link rel="stylesheet" href="../css/Cssbejelent.css">
</head>

<body>
<header>
    <h1>Műalkotások Világa</h1>
    <nav>
        <ul>
            <li><a href="index.php">Főoldal</a></li>
            <li><a href="info.php">Információ</a></li>
            <li><a href="kosar.php">Kosár</a></li>
            <li><a href="profil.php">Profil</a></li>
            <li><a href="velemeny.php">Velemeny</a></li>
            <li><a href="bejelentkezes.php">Bejelentkezés</a></li>
            <li><a href="regisztracio.php">Regisztráció</a></li>
            <li><a href="kijelentkezes.php">Kijelentkezés</a></li>
            <form action="index.php" method="get">
                <label>
                    <input type="text" name="search_term" class="kereso-doboz" placeholder="Keresés...">
                </label>
                <button type="submit" class="kereso-gomb">🔍</button>
            </form>
            <div>
                <?php if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["search_term"])): ?>
                    <p><?php echo $search_result; ?></p>
                <?php endif; ?>
            </div>
        </ul>
    </nav>
</header>
<main id="page" >
    <div class="login-box">
        <div class="login-header">
            <header>Saját profiladatok</header>
        </div>
        <div class="input-box">
            <label>
                <input type="text" class="input-field" value="Felhasználónév: <?php echo $_SESSION['username']; ?>" readonly>
            </label>
        </div>
        <div class="input-box">
            <label>
                <input type="password" class="input-field" value="Jelszó: *********" readonly>
            </label>
        </div>
        <div class="input-box">
            <label>
                <input type="email" class="input-field" value="Email-cím: <?php echo $users[$current_user_index]['email']; ?>" readonly>
            </label>
        </div>

        <form method="post">
            <div class="input-box">
                <input type="submit" name="delete_profile" class="input-field" value="Profil törlése">
            </div>
        </form>
        <form method="post" enctype="multipart/form-data">
            <div class="input-box">
                <label for="profile_picture">Profilkép feltöltése:</label>
                <input type="file"  name="profile-pic" id="profile_picture" accept="image/*">
            </div>
            <div class="input-box">
                <input type="submit"  name="upload_profile_pic" class="input-field" value="Feltöltés">
            </div>
        </form>

        <form method="post" enctype="multipart/form-data">
            <div class="input-box">
                <label for="new-profile-pic">Új profilkép kiválasztása:</label>
                <input type="file" name="new_profile_pic" id="new-profile-pic" accept="image/*">
            </div>
            <div class="input-box">
                <input type="submit" name="modify_profile_pic" class="input-field" value="Profilkép módosítása">
            </div>
        </form>

    </div>
</main>
</body>
</html>