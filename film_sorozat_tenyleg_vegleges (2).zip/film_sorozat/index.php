<?php
global $pdo;
session_start();
include('db.php');

if (!isset($_SESSION['felhasználónév'])) {
    header('Location: login.php');
    exit();
}

$stmt_film = $pdo->query("SELECT * FROM Film");
$filmek = $stmt_film->fetchAll();

$stmt_sorozat = $pdo->query("SELECT * FROM Sorozat");
$sorozatok = $stmt_sorozat->fetchAll();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Film és Sorozat Rendszer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        header {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }
        .container {
            margin: 20px;
        }
        .list {
            margin-top: 20px;
        }
        .item {
            background-color: #f4f4f4;
            padding: 10px;
            margin-bottom: 10px;
        }
        a {
            color: #fff;
            background-color: red;
            padding: 10px;
            text-decoration: none;
            border-radius: 5px;
            margin: 5px;
        }
        a:hover {
            background-color: darkred;
        }
        .logout {
            color: white;
            background-color: red;
        }
    </style>
</head>
<body>

<header>
    <h1>Üdvözlünk, <?php echo $_SESSION['felhasználónév']; ?>!</h1>
    <p>
        <a href="add_film.php">Új film hozzáadása</a> |
        <a href="add_film.php">Új sorozat hozzáadása</a> |
        <a href="rate_film.php">Film értékelése</a> |
        <a href="rate_film.php">Sorozat értékelése</a> |
        <a href="register.php">Regisztráció</a> |
        <a href="legmagasabb_ertekeles_mufajonkent.php">Lekérdezések</a>
        <a href="logout.php" class="logout">Kijelentkezés</a>
    </p>
</header>

<div class="container">
    <h2>Filmek Listája</h2>
    <div class="list">
        <?php
        if ($filmek) {
            foreach ($filmek as $film) {
                echo "<div class='item'>";
                echo "<h3>" . htmlspecialchars($film['cím']) . "</h3>";
                echo "<p>Játékidő: " . $film['játékidő'] . " perc</p>";
                echo "<p>Megjelenés éve: " . $film['megjelenés_éve'] . "</p>";
                echo "</div>";
            }
        } else {
            echo "<p>Nincs film az adatbázisban.</p>";
        }
        ?>
    </div>

    <h2>Sorozatok Listája</h2>
    <div class="list">
        <?php
        if ($sorozatok) {
            foreach ($sorozatok as $sorozat) {
                echo "<div class='item'>";
                echo "<h3>" . htmlspecialchars($sorozat['cím']) . "</h3>";
                echo "<p>Évadok száma: " . $sorozat['hány_évad'] . "</p>";
                echo "<p>Részek száma: " . $sorozat['hány_rész'] . "</p>";
                echo "</div>";
            }
        } else {
            echo "<p>Nincs sorozat az adatbázisban.</p>";
        }
        ?>

    </div>
</div>

</body>
</html>
