<?php
global $pdo;
session_start();
include('db.php');

if (!isset($_SESSION['felhasználónév'])) {
    header('Location: login.php');
    exit();
}

$query1 = "
SELECT Filmműfajok.műfaj, MAX(Filmértékelés.értékelés) AS LegmagasabbÉrtékelés
FROM Filmműfajok
JOIN Film ON Filmműfajok.cím = Film.cím
JOIN Filmértékelés ON Film.cím = Filmértékelés.cím
GROUP BY Filmműfajok.műfaj;
";

$query2 = "
SELECT Színész.név, COUNT(Szerepel.szerep) AS SzerepekSzáma
FROM Színész
JOIN Szerepel ON Színész.név = Szerepel.név
WHERE Szerepel.cím IN (SELECT cím FROM Film)
GROUP BY Színész.név;
";

$query3 = "
SELECT 
    Felhasználó.felhasználónév, 
    Filmértékelés.cím, 
    Filmértékelés.értékelés AS Legmagasabbértékelésitt
FROM Filmértékelés
JOIN Felhasználó ON Felhasználó.felhasználónév = Filmértékelés.felhasználónév
WHERE Filmértékelés.értékelés = (
    SELECT MAX(értékelés)
    FROM Filmértékelés AS allek
    WHERE allek.felhasználónév = Filmértékelés.felhasználónév
)
GROUP BY Felhasználó.felhasználónév
";

try {
    $stmt1 = $pdo->query($query1);
    $filmEredmenyek = $stmt1->fetchAll();

    $stmt2 = $pdo->query($query2);
    $szineszEredmenyek = $stmt2->fetchAll();

    $stmt3 = $pdo->query($query3);
    $felhasznaloEredmenyek = $stmt3->fetchAll();
} catch (PDOException $e) {
    echo "Hiba történt: " . $e->getMessage();
    die();
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Adatbázis Lekérdezések</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 70%;
            border-collapse: collapse;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
<h1>Adatok Megjelenítése</h1>

<h2>Filmek Legmagasabb Értékelése Műfajonként</h2>
<table>
    <tr>
        <th>Műfaj</th>
        <th>Legmagasabb Értékelés</th>
    </tr>
    <?php foreach ($filmEredmenyek as $row): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['műfaj']); ?></td>
            <td><?php echo htmlspecialchars($row['LegmagasabbÉrtékelés']); ?></td>
        </tr>
    <?php endforeach; ?>
</table>
<h2>Színészek Szerepeinek Száma Filmekben</h2>
<table>
    <tr>
        <th>Színész</th>
        <th>Szerepek Száma</th>
    </tr>
    <?php foreach ($szineszEredmenyek as $row): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['név']); ?></td>
            <td><?php echo htmlspecialchars($row['SzerepekSzáma']); ?></td>
        </tr>
    <?php endforeach; ?>
</table>

<h2>Felhasználók Legmagasabb Értékelései</h2>
<table>
    <tr>
        <th>Felhasználónév</th>
        <th>Film Cím</th>
        <th>Legmagasabb Értékelés</th>
    </tr>
    <?php foreach ($felhasznaloEredmenyek as $row): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['felhasználónév']); ?></td>
            <td><?php echo htmlspecialchars($row['cím']); ?></td>
            <td><?php echo htmlspecialchars($row['Legmagasabbértékelésitt']); ?></td>
        </tr>
    <?php endforeach; ?>
</table>
</body>
</html>

