<?php
global $pdo;
session_start();
include('db.php');

if (!isset($_SESSION['felhasználónév'])) {
    header('Location: login.php');
    exit();
}

$stmt_film = $pdo->query("SELECT * FROM Film");
$filmek = $stmt_film->fetchAll();

$stmt_sorozat = $pdo->query("SELECT * FROM Sorozat");
$sorozatok = $stmt_sorozat->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cím = $_POST['cím'];
    $értékelés = $_POST['értékelés'];
    $felhasználónév = $_SESSION['felhasználónév'];
    $típus = $_POST['típus'];

    if ($típus == 'film') {
        $stmt = $pdo->prepare("INSERT INTO filmértékelés (felhasználónév, cím, értékelés) VALUES (?, ?, ?)");
        $stmt->execute([$felhasználónév, $cím, $értékelés]);
    } elseif ($típus == 'sorozat') {
        $stmt = $pdo->prepare("INSERT INTO sorozatértékelés (felhasználónév, cím, értékelés) VALUES (?, ?, ?)");
        $stmt->execute([$felhasználónév, $cím, $értékelés]);
    }
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Film és Sorozat Értékelés</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        header {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }
        .container {
            margin: 20px;
        }
        .item {
            background-color: #f4f4f4;
            padding: 10px;
            margin-bottom: 10px;
        }
        a {
            color: #fff;
            background-color: red;
            padding: 10px;
            text-decoration: none;
            border-radius: 5px;
            margin: 5px;
        }
        a:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>

<header>
    <h1>Film és Sorozat Értékelése</h1>
    <p><a href="index.php">Vissza a főoldalra</a></p>
</header>

<div class="container">
    <h2>Filmek értékelése</h2>
    <form method="POST">
        <label for="cím">Film cím:</label>
        <select name="cím" id="cím">
            <?php
            foreach ($filmek as $film) {
                echo "<option value='" . $film['cím'] . "'>" . htmlspecialchars($film['cím']) . "</option>";
            }
            ?>
        </select>
        <br>
        <label for="értékelés">Értékelés (0-10):</label>
        <input type="number" name="értékelés" id="értékelés" min="0" max="10" step="0.1" required>
        <br>
        <input type="hidden" name="típus" value="film">
        <button type="submit">Értékelés mentése</button>
    </form>

    <h2>Sorozatok értékelése</h2>
    <form method="POST">
        <label for="cím">Sorozat cím:</label>
        <select name="cím" id="cím">
            <?php
            foreach ($sorozatok as $sorozat) {
                echo "<option value='" . $sorozat['cím'] . "'>" . htmlspecialchars($sorozat['cím']) . "</option>";
            }
            ?>
        </select>
        <br>
        <label for="értékelés">Értékelés (0-10):</label>
        <input type="number" name="értékelés" id="értékelés" min="0" max="10" step="0.1" required>
        <br>
        <input type="hidden" name="típus" value="sorozat">
        <button type="submit">Értékelés mentése</button>
    </form>
</div>

</body>
</html>
