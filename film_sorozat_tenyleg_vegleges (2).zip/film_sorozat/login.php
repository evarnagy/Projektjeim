<?php
global $pdo;
session_start();
include('db.php');

if (isset($_POST['submit'])) {
    $felhasználónév = $_POST['felhasználónév'];
    $jelszó = $_POST['jelszó'];

    $stmt = $pdo->prepare("SELECT * FROM Felhasználó WHERE felhasználónév = ?");
    $stmt->execute([$felhasználónév]);
    $user = $stmt->fetch();

    if ($user && $user['jelszó'] == $jelszó) {
        $_SESSION['felhasználónév'] = $user['felhasználónév'];
        header('Location: index.php');
        exit();
    } else {
        $error = "Hibás felhasználónév vagy jelszó!";
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Bejelentkezés</title>
</head>
<body>
<h2>Bejelentkezés</h2>
<form method="post">
    <label for="felhasználónév">Felhasználónév:</label>
    <input type="text" name="felhasználónév" required><br><br>
    <label for="jelszó">Jelszó:</label>
    <input type="password" name="jelszó" required><br><br>
    <button type="submit" name="submit">Bejelentkezés</button>
</form>
<?php if (isset($error)) echo "<p>$error</p>"; ?>
</body>
</html>
