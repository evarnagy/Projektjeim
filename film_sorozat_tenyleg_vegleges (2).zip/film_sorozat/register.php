<?php
global $pdo;
session_start();
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $felhasználónév = $_POST['felhasználónév'];
    $jelszó = $_POST['jelszó'];
    $név = $_POST['név'];

    $stmt = $pdo->prepare("SELECT * FROM Felhasználó WHERE felhasználónév = ?");
    $stmt->execute([$felhasználónév]);
    if ($stmt->rowCount() > 0) {
        echo "Ez a felhasználónév már foglalt!";
    } else {
        $stmt = $pdo->prepare("INSERT INTO Felhasználó (felhasználónév, jelszó, név) VALUES (?, ?, ?)");
        $stmt->execute([$felhasználónév, $jelszó, $név]);
        header('Location: login.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisztráció</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        header {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }
        .container {
            margin: 20px;
        }
        form {
            background-color: #f4f4f4;
            padding: 20px;
            border-radius: 5px;
            width: 300px;
            margin: 0 auto;
        }
        input {
            margin: 10px 0;
            padding: 10px;
            width: 100%;
            border-radius: 5px;
        }
        button {
            background-color: red;
            color: white;
            padding: 10px;
            border: none;
            width: 100%;
            border-radius: 5px;
        }
        button:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>

<header>
    <h1>Regisztráció</h1>
</header>

<div class="container">
    <form method="POST">
        <label for="felhasználónév">Felhasználónév:</label>
        <input type="text" name="felhasználónév" id="felhasználónév" required>

        <label for="jelszó">Jelszó:</label>
        <input type="password" name="jelszó" id="jelszó" required>

        <label for="név">Név:</label>
        <input type="text" name="név" id="név" required>

        <button type="submit">Regisztrálás</button>
    </form>
</div>

</body>
</html>

