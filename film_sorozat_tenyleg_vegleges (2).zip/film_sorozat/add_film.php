<?php
global $pdo;
session_start();
include('db.php');

if (!isset($_SESSION['felhasználónév'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cím = $_POST['cím'];
    $megjelenés_éve = $_POST['megjelenés_éve'];
    $típus = $_POST['típus'];

    if ($típus == 'film') {
        $játékidő = $_POST['játékidő'];
        $stmt = $pdo->prepare("INSERT INTO Film (cím, játékidő, megjelenés_éve) VALUES (?, ?, ?)");
        $stmt->execute([$cím, $játékidő, $megjelenés_éve]);
    }

    elseif ($típus == 'sorozat') {
        $hány_évad = $_POST['hány_évad'];
        $hány_rész = $_POST['hány_rész'];
        $stmt = $pdo->prepare("INSERT INTO Sorozat (cím, hány_évad, hány_rész) VALUES (?, ?, ?)");
        $stmt->execute([$cím, $hány_évad, $hány_rész]);
    }

    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Új film/sorozat hozzáadása</title>
</head>
<body>

<h1>Új film vagy sorozat hozzáadása</h1>
<form method="POST">
    <label for="cím">Cím:</label>
    <input type="text" name="cím" id="cím" required><br><br>

    <label for="megjelenés_éve">Megjelenés éve:</label>
    <input type="number" name="megjelenés_éve" id="megjelenés_éve" required><br><br>

    <label for="típus">Típus:</label>
    <select name="típus" id="típus" required>
        <option value="film">Film</option>
        <option value="sorozat">Sorozat</option>
    </select><br><br>

    <div id="film-fields" style="display: none;">
        <label for="játékidő">Játékidő (film esetén):</label>
        <input type="number" name="játékidő" id="játékidő"><br><br>
    </div>

    <div id="sorozat-fields" style="display: none;">
        <label for="hány_évad">Évadok száma (sorozat esetén):</label>
        <input type="number" name="hány_évad" id="hány_évad"><br><br>

        <label for="hány_rész">Részek száma (sorozat esetén):</label>
        <input type="number" name="hány_rész" id="hány_rész"><br><br>
    </div>

    <button type="submit">Hozzáadás</button>
</form>

<script>
    document.getElementById('típus').addEventListener('change', function() {
        if (this.value == 'sorozat') {
            document.getElementById('sorozat-fields').style.display = 'block';
            document.getElementById('film-fields').style.display = 'none';
        } else if (this.value == 'film') {
            document.getElementById('film-fields').style.display = 'block';
            document.getElementById('sorozat-fields').style.display = 'none';
        }
    });
</script>

</body>
</html>
